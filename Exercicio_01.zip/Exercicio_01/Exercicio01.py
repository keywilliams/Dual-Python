
fich = open("C:/Users/m89501426/OneDrive - Crédito Agrícola/Desktop/Dual/Exercicio_01/modulo3-Paises.csv", "r")
linhas = fich.readlines()
fich.close()

tabela = []   
categorias = "Sair"
paises = ""

for i, linha in enumerate(linhas):  
    colunas=linha.split(";")
    if i > 0:
        datamov = colunas[8].replace("\n", "").split("-")
        ##            Order ID,   Product,    Category,   Unit Price, Quantity,   (Unit Price * Quantity),                                                    Customer,   Ship City,  Ship Country, Order Date, Ano
        tabela.append([colunas[0], colunas[1], colunas[2], colunas[3], colunas[4], (float(colunas[3].replace(",", "."))*float(colunas[4].replace(",", "."))), colunas[5], colunas[6], colunas[7], colunas[8], datamov[2]])  

        ## Listar as Categorias
        if not categorias.__contains__(colunas[2]) and i > 0:
            if categorias:
                categorias += ","
            categorias += colunas[2]
        
        ## Listar os Paises
        if not paises.__contains__(colunas[7]):
            if paises:
                paises += ","
            paises += colunas[7]

paises = paises.split(",")
categorias = categorias.split(",")
b = 0
while True:
    for i, categ in enumerate(categorias):
        print(i, categ)
    try:
        b = input("\nEscolha a categoria:")
        b = int(b)
    except Exception as erro:
        print()

    if b in range(0, len(categorias)):
        break
    else:
        print("O num inserido não pertecen a lista!\n")

print(f"Categoria selecionada: {categorias[b]}\n")

paisesXvalor = []
if b > 0:
    for pais in paises:
        valor = 0
        for i, linha in enumerate(tabela):
            if linha[2] == categorias[b]:
                if linha[8] == pais:
                    valor+=linha[5]
        paisesXvalor.append([pais, round(valor, 2)])
    for pXv in paisesXvalor:
        print(pXv[0], "-", "{0:7.2f}€".format(float(pXv[1])))
else:
    print("Obrigado!\n")


